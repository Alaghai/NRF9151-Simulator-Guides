MICRO SIMULATOR PROTOCOL VERSION 7 - BIG-ENDIAN PACKAGE

Purpose
-------
This package standardizes every multi-byte protocol field to big-endian
(network byte order), retains the Version 6 timestamp specification, updates
the packet decoder and test vectors, and replaces the TCP server's recv()-based
logging with a real TCP stream parser.

Breaking change
---------------
Version 7 is not wire-compatible with earlier packet versions. The simulator,
server/parser, packet decoder, fixed packet vectors, and receiving integration
must be updated together.

Version 7 packet rules
----------------------
- Header: 0xAB
- Property: 0x10
- Length: uint16 big-endian, counts Command + Payload
- CRC: CRC-16/XMODEM over Payload only, uint16 big-endian on the wire
- Sequence ID: uint16 big-endian
- Command: 0x01 heartbeat or 0x10 location
- All remaining multi-byte payload fields: big-endian
- Default simulator wire mode: binary

Timestamp specification
-----------------------
- uint64, exactly 8 bytes
- big-endian
- Unix epoch milliseconds
- UTC
- zero means unavailable
- heartbeat timestamp = state sample time
- location timestamp = GNSS fix time

Files
-----
2_Simulator_Protocol_Decisions_and_Usage_v7_BIG_ENDIAN.docx
    Corrected protocol and usage documentation.
main.c
    nRF9151 simulator source.
micro_packet_decoder.py
    Paste-in packet decoder and validation utility.
test_micro_packet_decoder.py
    Decoder/protocol regression tests.
micro_tcp_server.py
    Persistent TCP server with binary and ASCII-HEX stream framing.
test_micro_tcp_server.py
    TCP stream parser regression tests.

Run decoder tests
-----------------
python test_micro_packet_decoder.py

Run TCP parser tests
--------------------
python test_micro_tcp_server.py

Decode one packet
-----------------
python micro_packet_decoder.py

Then paste packet HEX and press Enter.

Run the TCP server
------------------
Keep micro_tcp_server.py and micro_packet_decoder.py in the same directory:

sudo cp micro_tcp_server.py /root/
sudo cp micro_packet_decoder.py /root/
sudo chmod +x /root/micro_tcp_server.py
sudo python3 /root/micro_tcp_server.py

Recommended simulator commands
------------------------------
mode binary
send sample_hb_beacon
send hb
send loc

Important AB distinction
------------------------
Binary mode begins with one actual byte 0xAB. Its raw TCP HEX begins AB10...
ASCII-HEX mode begins with text characters 'A' and 'B', which are bytes 0x41
and 0x42. Its raw TCP HEX begins 41423130..., although an ASCII log displays
AB10.... A receiver expecting a binary 0xAB header will not recognize ASCII
bytes 0x41 0x42 as that header.

TCP framing
-----------
TCP is a byte stream. One recv() call is not guaranteed to contain one complete
packet. The included server accumulates bytes and uses the Version 7 big-endian
Length field to extract complete packets. Total packet bytes = 8 + Length.
