#!/usr/bin/env python3
"""Persistent Micro TCP test server with real stream framing.

Version 7 protocol assumptions:
  - Binary packet header byte: 0xAB
  - Property byte: 0x10
  - Length: bytes 2-3, uint16 big-endian, counts Command + Payload
  - Total packet bytes: 8 + Length
  - All multi-byte packet fields use big-endian byte order

The server accepts either:
  1. Binary mode: actual bytes beginning AB 10 ...
  2. ASCII-HEX mode: text characters beginning "AB10..."

TCP is a byte stream, so recv() boundaries are not treated as packet boundaries.
The parser accumulates data until a complete packet is available.
"""

from __future__ import annotations

import binascii
import datetime
import pathlib
import socket
import threading
import traceback
from dataclasses import dataclass
from typing import Iterable

HOST = "0.0.0.0"
PORT = 5000
LOG_FILE = pathlib.Path("/root/micro_tcp_packets.log")
RESPONSE_MODE_FILE = pathlib.Path("/root/micro_response_mode.txt")
MAX_PACKET_BYTES = 4096
HEADER = 0xAB
PROPERTY = 0x10
FIXED_PREFIX_BYTES = 8

LOG_LOCK = threading.Lock()
HEX_BYTES = set(b"0123456789abcdefABCDEF")
WHITESPACE_BYTES = set(b" \t\r\n")

try:
    from micro_packet_decoder import decode_packet
except Exception:  # The server can still frame and log without the decoder.
    decode_packet = None


def utc_timestamp() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat().replace("+00:00", "Z")


def safe_ascii(data: bytes) -> str:
    out: list[str] = []
    for value in data:
        if 32 <= value <= 126:
            out.append(chr(value))
        elif value in (10, 13):
            out.append("\\n")
        else:
            out.append(".")
    return "".join(out)


def read_response_mode() -> str:
    if not RESPONSE_MODE_FILE.exists():
        return "OK"
    value = RESPONSE_MODE_FILE.read_text(encoding="utf-8").strip()
    return value or "OK"


def build_response(mode: str, packet: bytes) -> bytes:
    """Build one response for one completely framed Micro packet."""
    mode = mode.strip()
    if mode == "OK":
        return b"OK\n"
    if mode == "CONFIG_NONE":
        return b"CONFIG_NONE\n"
    if mode in {"ECHO_HEX", "ECHO_PACKET_HEX"}:
        return b"RX_HEX:" + binascii.hexlify(packet).upper() + b"\n"
    if mode.startswith("CONFIG_UPDATE_ASCII_HEX:"):
        return mode.encode("ascii") + b"\n"
    if mode.startswith("BINARY_HEX:"):
        hex_part = mode.split(":", 1)[1].strip()
        return bytes.fromhex(hex_part)
    return b"OK\n"


@dataclass(frozen=True)
class FramedPacket:
    wire_mode: str
    packet: bytes


class MicroStreamParser:
    """Incrementally extract binary or ASCII-HEX Micro packets from TCP data.

    The parser permits the sender to switch wire mode on the same connection.
    After each complete packet it returns to automatic mode detection.
    """

    def __init__(self, max_packet_bytes: int = MAX_PACKET_BYTES):
        self.max_packet_bytes = max_packet_bytes
        self._raw = bytearray()
        self._mode: str | None = None
        self._ascii_hex = bytearray()
        self.diagnostics: list[str] = []

    def feed(self, data: bytes) -> list[FramedPacket]:
        if data:
            self._raw.extend(data)
        packets: list[FramedPacket] = []

        while True:
            if self._mode is None:
                if not self._detect_mode():
                    break

            before = (len(self._raw), len(self._ascii_hex), self._mode)
            if self._mode == "binary":
                packet = self._extract_binary()
            else:
                packet = self._extract_ascii_hex()

            if packet is None:
                after = (len(self._raw), len(self._ascii_hex), self._mode)
                if after != before and self._mode is None:
                    continue
                break

            packets.append(packet)
            self._mode = None

        return packets

    def _detect_mode(self) -> bool:
        if self._ascii_hex:
            self._mode = "ascii_hex"
            return True

        # Remove harmless whitespace between ASCII-HEX packets.
        while self._raw and self._raw[0] in WHITESPACE_BYTES:
            del self._raw[0]

        if not self._raw:
            return False

        if self._raw[0] == HEADER:
            self._mode = "binary"
            return True

        if self._raw[0] in (ord("A"), ord("a")):
            if len(self._raw) < 2:
                return False
            if self._raw[1] in (ord("B"), ord("b")):
                self._mode = "ascii_hex"
                return True

        # Find the next possible binary or ASCII packet header and discard noise.
        binary_index = self._raw.find(bytes([HEADER]))
        upper_raw = bytes(self._raw).upper()
        ascii_index = upper_raw.find(b"AB")
        candidates = [idx for idx in (binary_index, ascii_index) if idx >= 0]

        if not candidates:
            # Retain a trailing 'A' because the next recv() may begin with 'B'.
            keep = 1 if self._raw[-1] in (ord("A"), ord("a")) else 0
            discard = len(self._raw) - keep
            if discard:
                self.diagnostics.append(f"Discarded {discard} non-packet byte(s) while searching for AB.")
                del self._raw[:discard]
            return False

        start = min(candidates)
        if start > 0:
            self.diagnostics.append(f"Discarded {start} leading byte(s) before a possible AB header.")
            del self._raw[:start]
        return self._detect_mode()

    def _extract_binary(self) -> FramedPacket | None:
        if len(self._raw) < 4:
            return None

        if self._raw[0] != HEADER:
            self._mode = None
            return None

        if self._raw[1] != PROPERTY:
            self.diagnostics.append(
                f"Rejected binary header AB followed by property 0x{self._raw[1]:02X}; expected 0x{PROPERTY:02X}."
            )
            del self._raw[0]
            self._mode = None
            return None

        declared_length = int.from_bytes(self._raw[2:4], "big")
        total_bytes = FIXED_PREFIX_BYTES + declared_length
        if declared_length < 1 or total_bytes > self.max_packet_bytes:
            self.diagnostics.append(
                f"Rejected binary length {declared_length}; total packet size would be {total_bytes} bytes."
            )
            del self._raw[0]
            self._mode = None
            return None

        if len(self._raw) < total_bytes:
            return None

        packet = bytes(self._raw[:total_bytes])
        del self._raw[:total_bytes]
        return FramedPacket("binary", packet)

    def _extract_ascii_hex(self) -> FramedPacket | None:
        # Consume all currently available ASCII HEX characters/whitespace.
        consumed = 0
        for value in self._raw:
            if value in HEX_BYTES:
                self._ascii_hex.append(value)
                consumed += 1
            elif value in WHITESPACE_BYTES:
                consumed += 1
            else:
                break
        if consumed:
            del self._raw[:consumed]

        upper = bytes(self._ascii_hex).upper()
        start = upper.find(b"AB10")
        if start < 0:
            # Keep at most the final three characters, enough for a split AB10 header.
            if len(self._ascii_hex) > 3:
                discard = len(self._ascii_hex) - 3
                self.diagnostics.append(
                    f"Discarded {discard} ASCII-HEX character(s) while searching for AB10."
                )
                del self._ascii_hex[:discard]
            return None

        if start > 0:
            self.diagnostics.append(
                f"Discarded {start} ASCII-HEX character(s) before an AB10 packet header."
            )
            del self._ascii_hex[:start]
            upper = bytes(self._ascii_hex).upper()

        if len(upper) < 8:
            return None

        try:
            declared_length = int(upper[4:8].decode("ascii"), 16)
        except ValueError:
            self.diagnostics.append("Invalid ASCII-HEX length field after AB10.")
            del self._ascii_hex[0]
            self._mode = None
            return None

        total_bytes = FIXED_PREFIX_BYTES + declared_length
        total_hex_chars = total_bytes * 2
        if declared_length < 1 or total_bytes > self.max_packet_bytes:
            self.diagnostics.append(
                f"Rejected ASCII-HEX length {declared_length}; total packet size would be {total_bytes} bytes."
            )
            del self._ascii_hex[0]
            self._mode = None
            return None

        if len(self._ascii_hex) < total_hex_chars:
            return None

        packet_hex = bytes(self._ascii_hex[:total_hex_chars])
        del self._ascii_hex[:total_hex_chars]
        try:
            packet = bytes.fromhex(packet_hex.decode("ascii"))
        except ValueError:
            self.diagnostics.append("ASCII-HEX packet contained a non-HEX character.")
            self._mode = None
            return None
        return FramedPacket("ascii_hex", packet)


def _decoder_lines(packet: bytes) -> Iterable[str]:
    if decode_packet is None:
        yield "validation: decoder unavailable"
        return

    try:
        result = decode_packet(packet)
    except Exception as exc:
        yield f"validation: decoder error: {exc}"
        return

    yield f"validation: {'VALID' if result.valid else 'INVALID'}"
    for error in result.errors:
        yield f"validation_error: {error}"
    for warning in result.warnings:
        yield f"validation_warning: {warning}"

    for field in result.fields:
        if field.name.startswith("Sequence ID"):
            yield f"sequence_id: {field.decoded}"
        elif field.name == "Command":
            yield f"command: {field.decoded}"
        elif field.name == "IMEI":
            yield f"imei: {field.decoded}"
        elif field.name.startswith("Heartbeat state timestamp") or field.name.startswith("GNSS fix timestamp"):
            if isinstance(field.decoded, dict):
                yield f"timestamp_utc: {field.decoded.get('utc')}"


def log_packet(addr: tuple[str, int], framed: FramedPacket) -> None:
    timestamp = utc_timestamp()
    packet = framed.packet
    packet_hex = packet.hex().upper()
    lines = [
        f"\n[{timestamp}] {addr[0]}:{addr[1]}",
        f"wire_mode: {framed.wire_mode}",
        f"packet_length: {len(packet)} bytes",
        f"packet_hex: {packet_hex}",
        f"header_byte: 0x{packet[0]:02X}" if packet else "header_byte: unavailable",
    ]
    lines.extend(_decoder_lines(packet))

    text = "\n".join(lines) + "\n"
    with LOG_LOCK:
        print(text, end="")
        with LOG_FILE.open("a", encoding="utf-8") as handle:
            handle.write(text)


def log_diagnostics(addr: tuple[str, int], diagnostics: list[str]) -> None:
    if not diagnostics:
        return
    with LOG_LOCK:
        with LOG_FILE.open("a", encoding="utf-8") as handle:
            for message in diagnostics:
                line = f"[{utc_timestamp()}] {addr[0]}:{addr[1]} parser: {message}"
                print(line)
                handle.write(line + "\n")


def handle_client(conn: socket.socket, addr: tuple[str, int]) -> None:
    print(f"[{utc_timestamp()}] connection from {addr[0]}:{addr[1]}")
    parser = MicroStreamParser()

    try:
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                print(f"[{utc_timestamp()}] client disconnected: {addr[0]}:{addr[1]}")
                break

            # This log distinguishes actual binary 0xAB from ASCII characters A/B.
            print(
                f"[{utc_timestamp()}] recv chunk {len(chunk)} bytes from {addr[0]}:{addr[1]} "
                f"raw_hex={chunk.hex().upper()} ascii={safe_ascii(chunk)}"
            )

            framed_packets = parser.feed(chunk)
            if parser.diagnostics:
                log_diagnostics(addr, parser.diagnostics)
                parser.diagnostics.clear()

            for framed in framed_packets:
                log_packet(addr, framed)
                response_mode = read_response_mode()
                response = build_response(response_mode, framed.packet)
                if response:
                    conn.sendall(response)
                    print(f"response mode: {response_mode}")
                    print(f"response hex: {response.hex().upper()}")
                    print(f"response ascii: {safe_ascii(response)}")

    except Exception:
        print(f"[{utc_timestamp()}] connection error from {addr[0]}:{addr[1]}")
        traceback.print_exc()
    finally:
        try:
            conn.close()
        except Exception:
            pass
        print(f"[{utc_timestamp()}] closed connection from {addr[0]}:{addr[1]}")


def main() -> None:
    print(f"Starting Micro TCP test server on {HOST}:{PORT}")
    print(f"Log file: {LOG_FILE}")
    print(f"Response mode file: {RESPONSE_MODE_FILE}")
    print("Protocol: Version 7, all multi-byte fields big-endian")
    print("Accepted wire modes: binary 0xAB... and ASCII-HEX text AB...")

    if not RESPONSE_MODE_FILE.exists():
        RESPONSE_MODE_FILE.write_text("OK\n", encoding="utf-8")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(10)
        print("Waiting for persistent TCP connections...")

        while True:
            conn, addr = server.accept()
            thread = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            thread.start()


if __name__ == "__main__":
    main()
