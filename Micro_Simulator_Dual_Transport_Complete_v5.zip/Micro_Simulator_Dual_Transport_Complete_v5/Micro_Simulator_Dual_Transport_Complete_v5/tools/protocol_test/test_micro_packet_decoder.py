#!/usr/bin/env python3
import importlib.util
import sys
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).with_name("micro_packet_decoder.py")
spec = importlib.util.spec_from_file_location("micro_packet_decoder", MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

DEFAULT_TIMESTAMP_MS = 1_784_640_600_000
DEFAULT_TIMESTAMP_ISO = "2026-07-21T13:30:00.000Z"

GOOD = {
    "heartbeat_beacon": "AB10002569FD0001013836313335323036343035303738370000019F84DE77C0010107FF0101010FAC91003B91",
    "heartbeat_gps": "AB10002BFA890001013836313335323036343035303738370000019F84DE77C0010107FF01011002B513BCFB7CF3D000FF0000",
    "location": "AB10002867C80001103836313335323036343035303738370000019F84DE77C0010107FF02B513BCFB7CF3D000FF0000",
}

OLD_BAD = {
    "heartbeat": "AB102500D5E6230138363133353230363430353037383719EDB8266D50000000001007FF0101010FAC91003B91",
    "location": "AB10100026A1B2B50F1038363133353230363430353037383700506D26B8ED1900007FFFFAA2B580F5456B000FFF0FFF",
}


def make_packet(command: int, payload: bytes, sequence_id: int = 1) -> bytes:
    packet = bytearray(
        [0xAB, 0x10, 0x00, 0x00, 0x00, 0x00,
         (sequence_id >> 8) & 0xFF, sequence_id & 0xFF, command]
    )
    packet.extend(payload)
    packet[2:4] = (len(packet) - 8).to_bytes(2, "big")
    crc = mod.crc16_xmodem(bytes(packet[9:]))
    packet[4:6] = crc.to_bytes(2, "big")
    return bytes(packet)


def field_by_prefix(result, prefix: str):
    for field in result.fields:
        if field.name.startswith(prefix):
            return field
    raise AssertionError(f"No decoded field starts with {prefix!r}")


class DecoderTests(unittest.TestCase):
    def test_crc_check_vector(self):
        self.assertEqual(mod.crc16_xmodem(b"123456789"), 0x31C3)

    def test_corrected_packets_validate(self):
        for name, packet_hex in GOOD.items():
            with self.subTest(name=name):
                result = mod.decode_packet(bytes.fromhex(packet_hex))
                self.assertTrue(result.valid, result.errors)

    def test_old_packets_are_rejected(self):
        for name, packet_hex in OLD_BAD.items():
            with self.subTest(name=name):
                result = mod.decode_packet(bytes.fromhex(packet_hex))
                self.assertFalse(result.valid)
                self.assertTrue(any("Command" in error for error in result.errors))

    def test_ottawa_coordinates_decode(self):
        result = mod.decode_packet(bytes.fromhex(GOOD["location"]))
        decoded = {field.name: field.decoded for field in result.fields}
        self.assertAlmostEqual(decoded["Latitude (int32 big-endian / 1,000,000)"], 45.4215)
        self.assertAlmostEqual(decoded["Longitude (int32 big-endian / 1,000,000)"], -75.6972)

    def test_length_corruption_is_detected(self):
        packet = bytearray.fromhex(GOOD["heartbeat_beacon"])
        packet[2:4] = (16).to_bytes(2, "big")
        result = mod.decode_packet(bytes(packet))
        self.assertFalse(result.valid)
        self.assertTrue(any("Length mismatch" in error for error in result.errors))

    def test_all_multi_byte_header_fields_are_big_endian(self):
        packet = bytes.fromhex(GOOD["heartbeat_beacon"])
        self.assertEqual(packet[2:4], bytes.fromhex("0025"))
        self.assertEqual(packet[4:6], bytes.fromhex("69FD"))
        self.assertEqual(packet[6:8], bytes.fromhex("0001"))

    def test_timestamp_conversion_helpers(self):
        self.assertEqual(mod.iso8601_to_unix_ms("2026-07-21T13:30:00Z"), DEFAULT_TIMESTAMP_MS)
        self.assertEqual(mod.unix_ms_to_iso8601(DEFAULT_TIMESTAMP_MS), DEFAULT_TIMESTAMP_ISO)
        self.assertEqual(DEFAULT_TIMESTAMP_MS.to_bytes(8, "big").hex().upper(), "0000019F84DE77C0")

    def test_all_good_packets_use_timestamp_spec(self):
        for name, packet_hex in GOOD.items():
            with self.subTest(name=name):
                result = mod.decode_packet(bytes.fromhex(packet_hex))
                timestamp = field_by_prefix(result, "Heartbeat state timestamp") if name.startswith("heartbeat") else field_by_prefix(result, "GNSS fix timestamp")
                self.assertEqual(timestamp.raw_hex, "0000019F84DE77C0")
                self.assertEqual(timestamp.decoded["unix_ms"], DEFAULT_TIMESTAMP_MS)
                self.assertEqual(timestamp.decoded["utc"], DEFAULT_TIMESTAMP_ISO)
                self.assertEqual(timestamp.decoded["byte_order"], "big-endian")
                self.assertEqual(timestamp.decoded["unit"], "milliseconds")

    def test_zero_timestamp_means_unavailable(self):
        imei = b"861352064050787"
        payload = (
            imei
            + (0).to_bytes(8, "big")
            + bytes([0x01, 0x01])
            + (2047).to_bytes(2, "big")
            + bytes([0x01, 0x01, 0x01])
            + bytes.fromhex("0FAC91003B91")
        )
        result = mod.decode_packet(make_packet(0x01, payload))
        self.assertTrue(result.valid, result.errors)
        timestamp = field_by_prefix(result, "Heartbeat state timestamp")
        self.assertEqual(timestamp.decoded["unix_ms"], 0)
        self.assertEqual(timestamp.decoded["utc"], "unavailable")

    def test_location_fix_age_vector(self):
        fix_timestamp_ms = DEFAULT_TIMESTAMP_MS - 120_000
        imei = b"861352064050787"
        payload = (
            imei
            + fix_timestamp_ms.to_bytes(8, "big")
            + bytes([0x01, 0x01])
            + (2047).to_bytes(2, "big")
            + int(45_421_500).to_bytes(4, "big", signed=True)
            + int(-75_697_200).to_bytes(4, "big", signed=True)
            + (255).to_bytes(2, "big")
            + (0).to_bytes(2, "big")
        )
        result = mod.decode_packet(make_packet(0x10, payload))
        self.assertTrue(result.valid, result.errors)
        timestamp = field_by_prefix(result, "GNSS fix timestamp")
        self.assertEqual(timestamp.decoded["unix_ms"], fix_timestamp_ms)
        self.assertEqual(timestamp.decoded["utc"], "2026-07-21T13:28:00.000Z")


if __name__ == "__main__":
    unittest.main(verbosity=2)
