#!/usr/bin/env python3
"""Decode and validate Micro simulator heartbeat and LTE-M location packets.

Canonical packet rules implemented here:
  byte 0      Header      0xAB
  byte 1      Property    0x10
  bytes 2-3   Length      uint16 big-endian, Command + Payload bytes
  bytes 4-5   CRC         CRC-16/XMODEM over Payload only, stored big-endian
  bytes 6-7   Sequence ID uint16 big-endian
  byte 8      Command     0x01 heartbeat, 0x10 LTE-M location
  bytes 9+    Payload

Timestamp specification:
  uint64 big-endian Unix time in milliseconds since 1970-01-01T00:00:00Z.
  Value 0 means timestamp unavailable.

The tool accepts a plain HEX packet, HEX separated by spaces, or a simulator log
line such as "Dynamic heartbeat hex: AB...".
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from typing import Any, Iterable

HEADER = 0xAB
PROPERTY = 0x10
COMMAND_HEARTBEAT = 0x01
COMMAND_LOCATION = 0x10
COMMAND_OFFSET = 8
PAYLOAD_OFFSET = 9
COORD_SCALE = 1_000_000

BATTERY_NAMES = {0x00: "low", 0x01: "medium", 0x10: "high"}
CHARGING_NAMES = {0x01: "not charging", 0x10: "charging"}
OPCODE_NAMES = {
    0x01: "beacon detected",
    0x0A: "GPS safe zone",
    0x10: "GPS + LTE",
    0xA0: "trusted device detected",
}
GPS_OPCODES = {0x0A, 0x10}
ADDRESS_OPCODES = {0x01, 0xA0}
TIMESTAMP_EPOCH = "1970-01-01T00:00:00Z"
TIMESTAMP_UNIT = "milliseconds"
TIMESTAMP_BYTE_ORDER = "big-endian"
PROTOCOL_BYTE_ORDER = "big-endian"


@dataclass
class Field:
    offset: str
    name: str
    raw_hex: str
    decoded: Any


@dataclass
class DecodeResult:
    valid: bool
    packet_hex: str
    packet_bytes: int
    fields: list[Field]
    errors: list[str]
    warnings: list[str]
    diagnostics: list[str]

    def json_ready(self) -> dict[str, Any]:
        out = asdict(self)
        return out


def crc16_xmodem(data: bytes, initial_crc: int = 0x0000) -> int:
    """Exact equivalent of the CRC routine supplied by the server team.

    Parameters match CRC-16/XMODEM:
      polynomial 0x1021, init 0x0000, refin false, refout false, xorout 0x0000.
    The standard check value for b"123456789" is 0x31C3.
    """
    crc = initial_crc & 0xFFFF
    for value in data:
        crc = (((crc >> 8) & 0xFF) | ((crc << 8) & 0xFFFF)) & 0xFFFF
        crc ^= value
        crc ^= (crc & 0xFF) >> 4
        crc ^= ((crc << 8) << 4) & 0xFFFF
        crc ^= (((crc & 0xFF) << 4) << 1) & 0xFFFF
        crc &= 0xFFFF
    return crc




def unix_ms_to_iso8601(timestamp_ms: int) -> str | None:
    """Convert protocol Unix milliseconds to an ISO-8601 UTC string.

    A protocol value of zero means the timestamp is unavailable.
    """
    if timestamp_ms == 0:
        return None
    if timestamp_ms < 0:
        raise ValueError("Unix milliseconds cannot be negative for this uint64 field.")

    seconds, milliseconds = divmod(timestamp_ms, 1000)
    try:
        dt = datetime.fromtimestamp(seconds, tz=timezone.utc)
    except (OverflowError, OSError, ValueError) as exc:
        raise ValueError(f"Timestamp {timestamp_ms} ms is outside Python's supported date range.") from exc
    return dt.strftime("%Y-%m-%dT%H:%M:%S") + f".{milliseconds:03d}Z"


def iso8601_to_unix_ms(text: str) -> int:
    """Convert an ISO-8601 timestamp with an explicit timezone to Unix ms."""
    value = text.strip()
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("Use ISO-8601 such as 2026-07-21T13:30:00Z.") from exc
    if dt.tzinfo is None:
        raise ValueError("Timestamp must include Z or an explicit UTC offset.")
    timestamp_ms = int(round(dt.timestamp() * 1000))
    if timestamp_ms < 0 or timestamp_ms > 0xFFFFFFFFFFFFFFFF:
        raise ValueError("Timestamp is outside the uint64 Unix-millisecond range.")
    return timestamp_ms


def _only_hex_separators(text: str) -> bool:
    return re.fullmatch(r"[0-9A-Fa-f\s:_-]+", text) is not None


def normalize_hex_input(text: str) -> str:
    """Extract one packet from plain HEX or a simulator/relay log line."""
    text = text.strip()
    if not text:
        raise ValueError("No packet was supplied.")

    known_prefixes = (
        "MICRO_RELAY_TX_ASCII_HEX:",
        "MICRO_RELAY_TX_BINARY_HEX:",
        "Dynamic heartbeat hex:",
        "Dynamic location hex:",
    )
    for prefix in known_prefixes:
        idx = text.rfind(prefix)
        if idx >= 0:
            text = text[idx + len(prefix):].strip().splitlines()[0]
            break

    if _only_hex_separators(text):
        candidate = re.sub(r"[^0-9A-Fa-f]", "", text)
    else:
        # Select the longest plausible contiguous packet from mixed log text.
        candidates = re.findall(r"(?i)(?:[0-9a-f]{2}[\s:_-]*){8,}", text)
        if not candidates:
            raise ValueError("Could not find a HEX packet in the supplied text.")
        candidate = max(candidates, key=len)
        candidate = re.sub(r"[^0-9A-Fa-f]", "", candidate)

    if len(candidate) % 2:
        raise ValueError(f"HEX input has an odd number of characters ({len(candidate)}).")
    if len(candidate) < 18:
        raise ValueError("Packet is shorter than the 9-byte fixed header.")
    return candidate.upper()


def _hex(data: bytes) -> str:
    return data.hex().upper()


def _mac(data: bytes) -> str:
    return ":".join(f"{b:02X}" for b in data)


def _ascii_digits(data: bytes) -> str | None:
    try:
        value = data.decode("ascii")
    except UnicodeDecodeError:
        return None
    return value if len(value) == 15 and value.isdigit() else None


def _read(data: bytes, offset: int, size: int, name: str, errors: list[str]) -> bytes | None:
    end = offset + size
    if end > len(data):
        errors.append(
            f"{name} requires bytes {offset}-{end - 1}, but the packet ends at byte {len(data) - 1}."
        )
        return None
    return data[offset:end]


def _add(fields: list[Field], start: int, raw: bytes, name: str, decoded: Any) -> None:
    end = start + len(raw) - 1
    offset = str(start) if len(raw) == 1 else f"{start}-{end}"
    fields.append(Field(offset, name, _hex(raw), decoded))


def _diagnose_shifted_packet(data: bytes, diagnostics: list[str]) -> None:
    if len(data) <= COMMAND_OFFSET:
        return

    command = data[COMMAND_OFFSET]
    if command in (COMMAND_HEARTBEAT, COMMAND_LOCATION):
        return

    nearby = []
    for idx in range(6, min(12, len(data))):
        if data[idx] in (COMMAND_HEARTBEAT, COMMAND_LOCATION):
            nearby.append((idx, data[idx]))
    if nearby:
        matches = ", ".join(f"0x{value:02X} at byte {idx}" for idx, value in nearby)
        diagnostics.append(
            f"A valid command value exists near the expected position ({matches}). "
            "This usually means the sequence-ID width or another header field was shifted."
        )

    digit_runs = [(m.start(), m.group()) for m in re.finditer(rb"[0-9]{15}", data)]
    if digit_runs:
        starts = ", ".join(str(start) for start, _ in digit_runs)
        diagnostics.append(
            f"A 15-digit IMEI-like sequence starts at byte(s) {starts}; the canonical payload IMEI starts at byte 9."
        )


def decode_packet(packet: bytes) -> DecodeResult:
    fields: list[Field] = []
    errors: list[str] = []
    warnings: list[str] = []
    diagnostics: list[str] = []

    if len(packet) < PAYLOAD_OFFSET:
        errors.append("Packet is shorter than the 9-byte fixed header.")
        return DecodeResult(False, _hex(packet), len(packet), fields, errors, warnings, diagnostics)

    _add(fields, 0, packet[0:1], "Header", f"0x{packet[0]:02X}")
    if packet[0] != HEADER:
        errors.append(f"Header is 0x{packet[0]:02X}; expected 0x{HEADER:02X}.")

    _add(fields, 1, packet[1:2], "Property", f"0x{packet[1]:02X}")
    if packet[1] != PROPERTY:
        errors.append(f"Property is 0x{packet[1]:02X}; expected 0x{PROPERTY:02X}.")

    declared_length = int.from_bytes(packet[2:4], "big")
    actual_length = len(packet) - COMMAND_OFFSET
    _add(
        fields,
        2,
        packet[2:4],
        "Length (uint16 big-endian)",
        {"declared_command_plus_payload_bytes": declared_length, "actual": actual_length},
    )
    if declared_length != actual_length:
        errors.append(
            f"Length mismatch: field declares {declared_length} Command+Payload bytes, "
            f"but the packet contains {actual_length}."
        )

    received_crc_be = int.from_bytes(packet[4:6], "big")
    received_crc_le = int.from_bytes(packet[4:6], "little")
    calculated_crc = crc16_xmodem(packet[PAYLOAD_OFFSET:])
    _add(
        fields,
        4,
        packet[4:6],
        "CRC-16/XMODEM",
        {
            "received_big_endian": f"0x{received_crc_be:04X}",
            "calculated_over_payload": f"0x{calculated_crc:04X}",
            "valid": received_crc_be == calculated_crc,
        },
    )
    if received_crc_be != calculated_crc:
        errors.append(
            f"CRC mismatch: received 0x{received_crc_be:04X} from bytes {_hex(packet[4:6])}, "
            f"calculated 0x{calculated_crc:04X} over payload bytes 9-{len(packet)-1}."
        )
        if received_crc_le == calculated_crc:
            diagnostics.append(
                "The CRC value matches only when the two CRC bytes are interpreted little-endian. "
                "Version 7 uses big-endian for every multi-byte packet field."
            )

    sequence_id = int.from_bytes(packet[6:8], "big")
    _add(fields, 6, packet[6:8], "Sequence ID (uint16 big-endian)", sequence_id)

    command = packet[COMMAND_OFFSET]
    command_name = {
        COMMAND_HEARTBEAT: "heartbeat",
        COMMAND_LOCATION: "LTE-M location",
    }.get(command, "unknown")
    _add(fields, COMMAND_OFFSET, packet[COMMAND_OFFSET:COMMAND_OFFSET + 1], "Command", f"0x{command:02X} ({command_name})")
    if command not in (COMMAND_HEARTBEAT, COMMAND_LOCATION):
        errors.append(
            f"Command at byte 8 is 0x{command:02X}; expected 0x01 (heartbeat) or 0x10 (location)."
        )
        _diagnose_shifted_packet(packet, diagnostics)
        return DecodeResult(False, _hex(packet), len(packet), fields, errors, warnings, diagnostics)

    offset = PAYLOAD_OFFSET
    imei_raw = _read(packet, offset, 15, "IMEI", errors)
    if imei_raw is None:
        return DecodeResult(False, _hex(packet), len(packet), fields, errors, warnings, diagnostics)
    imei = _ascii_digits(imei_raw)
    _add(fields, offset, imei_raw, "IMEI (15 ASCII bytes)", imei if imei is not None else "invalid ASCII IMEI")
    if imei is None:
        errors.append("IMEI is not exactly 15 ASCII decimal digits at bytes 9-23.")
    offset += 15

    timestamp = _read(packet, offset, 8, "Timestamp", errors)
    if timestamp is None:
        return DecodeResult(False, _hex(packet), len(packet), fields, errors, warnings, diagnostics)
    timestamp_ms = int.from_bytes(timestamp, "big", signed=False)
    timestamp_label = (
        "Heartbeat state timestamp (uint64 big-endian Unix ms)"
        if command == COMMAND_HEARTBEAT
        else "GNSS fix timestamp (uint64 big-endian Unix ms)"
    )
    timestamp_utc: str | None
    try:
        timestamp_utc = unix_ms_to_iso8601(timestamp_ms)
    except ValueError as exc:
        timestamp_utc = None
        warnings.append(str(exc))

    _add(
        fields,
        offset,
        timestamp,
        timestamp_label,
        {
            "unix_ms": timestamp_ms,
            "utc": timestamp_utc if timestamp_utc is not None else "unavailable",
            "epoch": TIMESTAMP_EPOCH,
            "unit": TIMESTAMP_UNIT,
            "byte_order": TIMESTAMP_BYTE_ORDER,
            "meaning": (
                "time the heartbeat state was sampled"
                if command == COMMAND_HEARTBEAT
                else "time the transmitted GNSS coordinates were fixed"
            ),
        },
    )
    offset += 8

    battery_raw = _read(packet, offset, 1, "Battery", errors)
    charging_raw = _read(packet, offset + 1, 1, "Charging", errors)
    last_update_raw = _read(packet, offset + 2, 2, "lastUpdate", errors)
    if None in (battery_raw, charging_raw, last_update_raw):
        return DecodeResult(False, _hex(packet), len(packet), fields, errors, warnings, diagnostics)

    battery = battery_raw[0]
    charging = charging_raw[0]
    _add(fields, offset, battery_raw, "Battery level", BATTERY_NAMES.get(battery, f"unknown 0x{battery:02X}"))
    if battery not in BATTERY_NAMES:
        warnings.append(f"Unknown battery code 0x{battery:02X}.")
    offset += 1

    _add(fields, offset, charging_raw, "Charging state", CHARGING_NAMES.get(charging, f"unknown 0x{charging:02X}"))
    if charging not in CHARGING_NAMES:
        warnings.append(f"Unknown charging code 0x{charging:02X}.")
    offset += 1

    last_update = int.from_bytes(last_update_raw, "big")
    _add(fields, offset, last_update_raw, "lastUpdate (uint16 big-endian)", f"{last_update} minutes")
    offset += 2

    if command == COMMAND_HEARTBEAT:
        sw_raw = _read(packet, offset, 1, "Software version", errors)
        fw_raw = _read(packet, offset + 1, 1, "Firmware version", errors)
        opcode_raw = _read(packet, offset + 2, 1, "Opcode", errors)
        if None in (sw_raw, fw_raw, opcode_raw):
            return DecodeResult(False, _hex(packet), len(packet), fields, errors, warnings, diagnostics)

        _add(fields, offset, sw_raw, "Software version", sw_raw[0])
        offset += 1
        _add(fields, offset, fw_raw, "Firmware version", fw_raw[0])
        offset += 1
        opcode = opcode_raw[0]
        _add(fields, offset, opcode_raw, "Heartbeat opcode", f"0x{opcode:02X} ({OPCODE_NAMES.get(opcode, 'unknown')})")
        offset += 1

        if opcode in ADDRESS_OPCODES:
            address = _read(packet, offset, 6, "Beacon/trusted address", errors)
            if address is not None:
                label = "Beacon MAC" if opcode == 0x01 else "Trusted-device address/identity"
                _add(fields, offset, address, label, _mac(address))
                offset += 6
        elif opcode in GPS_OPCODES:
            offset = _decode_location_fields(packet, offset, fields, errors)
        else:
            errors.append(f"Unknown heartbeat opcode 0x{opcode:02X}; locationData length cannot be determined.")

    else:
        offset = _decode_location_fields(packet, offset, fields, errors)

    if offset < len(packet):
        trailing = packet[offset:]
        _add(fields, offset, trailing, "Unexpected trailing bytes", _hex(trailing))
        errors.append(f"Packet has {len(trailing)} unexpected trailing byte(s) beginning at byte {offset}.")
    elif offset > len(packet):
        errors.append("Packet ended before all fields could be decoded.")

    return DecodeResult(not errors, _hex(packet), len(packet), fields, errors, warnings, diagnostics)


def _decode_location_fields(packet: bytes, offset: int, fields: list[Field], errors: list[str]) -> int:
    lat_raw = _read(packet, offset, 4, "Latitude", errors)
    lon_raw = _read(packet, offset + 4, 4, "Longitude", errors)
    accuracy_raw = _read(packet, offset + 8, 2, "Accuracy", errors)
    speed_raw = _read(packet, offset + 10, 2, "Speed", errors)
    if None in (lat_raw, lon_raw, accuracy_raw, speed_raw):
        return len(packet)

    lat_scaled = int.from_bytes(lat_raw, "big", signed=True)
    lon_scaled = int.from_bytes(lon_raw, "big", signed=True)
    accuracy_scaled = int.from_bytes(accuracy_raw, "big", signed=False)
    speed_scaled = int.from_bytes(speed_raw, "big", signed=False)

    latitude = lat_scaled / COORD_SCALE
    longitude = lon_scaled / COORD_SCALE
    accuracy = accuracy_scaled / 10.0
    speed = speed_scaled / 10.0

    _add(fields, offset, lat_raw, "Latitude (int32 big-endian / 1,000,000)", latitude)
    offset += 4
    _add(fields, offset, lon_raw, "Longitude (int32 big-endian / 1,000,000)", longitude)
    offset += 4
    _add(fields, offset, accuracy_raw, "Accuracy (uint16 big-endian / 10)", f"{accuracy} m")
    offset += 2
    _add(fields, offset, speed_raw, "Speed (uint16 big-endian / 10)", f"{speed} m/s")
    offset += 2

    if not -90.0 <= latitude <= 90.0:
        errors.append(f"Decoded latitude {latitude} is outside -90..90 degrees.")
    if not -180.0 <= longitude <= 180.0:
        errors.append(f"Decoded longitude {longitude} is outside -180..180 degrees.")
    return offset


def print_human(result: DecodeResult) -> None:
    print(f"Packet: {result.packet_hex}")
    print(f"Total size: {result.packet_bytes} bytes")
    print(f"Overall result: {'VALID' if result.valid else 'INVALID'}")
    print()
    print(f"{'Offset':<10} {'Field':<46} {'Raw HEX':<34} Decoded")
    print("-" * 125)
    for field in result.fields:
        decoded = json.dumps(field.decoded, ensure_ascii=False) if isinstance(field.decoded, (dict, list)) else str(field.decoded)
        print(f"{field.offset:<10} {field.name:<46} {field.raw_hex:<34} {decoded}")

    for title, items in (
        ("ERRORS", result.errors),
        ("WARNINGS", result.warnings),
        ("DIAGNOSTICS", result.diagnostics),
    ):
        if items:
            print(f"\n{title}:")
            for item in items:
                print(f"- {item}")


def _read_input(args: Iterable[str]) -> str:
    joined = " ".join(args).strip()
    if joined:
        return joined
    if not sys.stdin.isatty():
        return sys.stdin.read()
    return input("Paste packet HEX and press Enter:\n> ")


def main() -> int:
    parser = argparse.ArgumentParser(description="Decode and validate a Micro simulator packet.")
    parser.add_argument("packet", nargs="*", help="Packet HEX or simulator log line. If omitted, prompts for paste.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON instead of a table.")
    parser.add_argument("--crc-self-test", action="store_true", help="Run the CRC check vector and exit.")
    parser.add_argument(
        "--timestamp-to-unix-ms",
        metavar="ISO8601",
        help="Convert an ISO-8601 timestamp such as 2026-07-21T13:30:00Z to Unix milliseconds and packet bytes.",
    )
    parser.add_argument(
        "--unix-ms-to-timestamp",
        metavar="UNIX_MS",
        help="Convert protocol Unix milliseconds to an ISO-8601 UTC timestamp.",
    )
    args = parser.parse_args()

    special_actions = sum(
        value is not None and value is not False
        for value in (args.crc_self_test, args.timestamp_to_unix_ms, args.unix_ms_to_timestamp)
    )
    if special_actions > 1:
        parser.error("Use only one conversion/self-test option at a time.")

    if args.crc_self_test:
        value = crc16_xmodem(b"123456789")
        print(f"CRC-16/XMODEM('123456789') = 0x{value:04X}")
        return 0 if value == 0x31C3 else 1

    if args.timestamp_to_unix_ms is not None:
        try:
            timestamp_ms = iso8601_to_unix_ms(args.timestamp_to_unix_ms)
        except ValueError as exc:
            print(f"Timestamp input error: {exc}", file=sys.stderr)
            return 2
        print(f"UTC timestamp: {unix_ms_to_iso8601(timestamp_ms)}")
        print(f"Unix milliseconds: {timestamp_ms}")
        print(f"8-byte big-endian HEX: {timestamp_ms.to_bytes(8, 'big').hex().upper()}")
        print(f"Simulator command: set timestamp {timestamp_ms}")
        return 0

    if args.unix_ms_to_timestamp is not None:
        try:
            timestamp_ms = int(args.unix_ms_to_timestamp, 10)
            if timestamp_ms < 0 or timestamp_ms > 0xFFFFFFFFFFFFFFFF:
                raise ValueError("Value is outside uint64 range.")
            timestamp_utc = unix_ms_to_iso8601(timestamp_ms)
        except ValueError as exc:
            print(f"Timestamp input error: {exc}", file=sys.stderr)
            return 2
        print(f"Unix milliseconds: {timestamp_ms}")
        print(f"UTC timestamp: {timestamp_utc if timestamp_utc is not None else 'unavailable'}")
        print(f"8-byte big-endian HEX: {timestamp_ms.to_bytes(8, 'big').hex().upper()}")
        return 0

    try:
        packet_hex = normalize_hex_input(_read_input(args.packet))
        result = decode_packet(bytes.fromhex(packet_hex))
    except ValueError as exc:
        print(f"Input error: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(result.json_ready(), indent=2, ensure_ascii=False))
    else:
        print_human(result)
    return 0 if result.valid else 1


if __name__ == "__main__":
    raise SystemExit(main())
