#!/usr/bin/env python3
import importlib.util
import sys
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).with_name("micro_tcp_server.py")
spec = importlib.util.spec_from_file_location("micro_tcp_server", MODULE_PATH)
server = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = server
spec.loader.exec_module(server)

PACKET_HEX = "AB10002569FD0001013836313335323036343035303738370000019F84DE77C0010107FF0101010FAC91003B91"
PACKET = bytes.fromhex(PACKET_HEX)


class StreamParserTests(unittest.TestCase):
    def test_binary_packet_split_across_recv_calls(self):
        parser = server.MicroStreamParser()
        self.assertEqual(parser.feed(PACKET[:3]), [])
        self.assertEqual(parser.feed(PACKET[3:17]), [])
        framed = parser.feed(PACKET[17:])
        self.assertEqual(len(framed), 1)
        self.assertEqual(framed[0].wire_mode, "binary")
        self.assertEqual(framed[0].packet, PACKET)

    def test_ascii_hex_packet_split_across_recv_calls(self):
        parser = server.MicroStreamParser()
        wire = PACKET_HEX.encode("ascii")
        self.assertEqual(parser.feed(wire[:1]), [])
        self.assertEqual(parser.feed(wire[1:19]), [])
        framed = parser.feed(wire[19:])
        self.assertEqual(len(framed), 1)
        self.assertEqual(framed[0].wire_mode, "ascii_hex")
        self.assertEqual(framed[0].packet, PACKET)

    def test_two_binary_packets_in_one_recv(self):
        parser = server.MicroStreamParser()
        framed = parser.feed(PACKET + PACKET)
        self.assertEqual([item.packet for item in framed], [PACKET, PACKET])

    def test_two_ascii_packets_in_one_recv(self):
        parser = server.MicroStreamParser()
        framed = parser.feed((PACKET_HEX + PACKET_HEX).encode("ascii"))
        self.assertEqual([item.packet for item in framed], [PACKET, PACKET])
        self.assertTrue(all(item.wire_mode == "ascii_hex" for item in framed))

    def test_mixed_wire_modes_on_one_connection(self):
        parser = server.MicroStreamParser()
        framed = parser.feed(PACKET + PACKET_HEX.encode("ascii"))
        self.assertEqual(len(framed), 2)
        self.assertEqual(framed[0].wire_mode, "binary")
        self.assertEqual(framed[1].wire_mode, "ascii_hex")

    def test_leading_noise_is_discarded(self):
        parser = server.MicroStreamParser()
        framed = parser.feed(b"noise" + PACKET)
        self.assertEqual(len(framed), 1)
        self.assertEqual(framed[0].packet, PACKET)
        self.assertTrue(parser.diagnostics)

    def test_ascii_ab_is_not_binary_header_byte(self):
        self.assertEqual(PACKET_HEX.encode("ascii")[:2], b"AB")
        self.assertEqual(PACKET_HEX.encode("ascii")[:2].hex().upper(), "4142")
        self.assertEqual(PACKET[:1].hex().upper(), "AB")
        self.assertNotEqual(PACKET_HEX.encode("ascii")[:1], PACKET[:1])

    def test_big_endian_length_controls_framing(self):
        self.assertEqual(PACKET[2:4], bytes.fromhex("0025"))
        declared = int.from_bytes(PACKET[2:4], "big")
        self.assertEqual(declared, 37)
        self.assertEqual(8 + declared, len(PACKET))


if __name__ == "__main__":
    unittest.main(verbosity=2)
