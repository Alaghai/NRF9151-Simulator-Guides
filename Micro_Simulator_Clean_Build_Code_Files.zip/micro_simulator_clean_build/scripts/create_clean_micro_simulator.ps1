# Cleanly create the Micro simulator application inside the Onomondo SoftSIM workspace.
# Run from the extracted package root or edit $PackageRoot manually.

$Workspace = "C:\Users\amiri\onomondo-softsim-test"
$BuildDir = "C:\b\micro_sim_clean"
$PackageRoot = Split-Path -Parent $PSScriptRoot

Set-Location $Workspace
Remove-Item Env:ZEPHYR_BASE -ErrorAction SilentlyContinue

Remove-Item -Recurse -Force ".\applications\micro_simulator" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force $BuildDir -ErrorAction SilentlyContinue

New-Item -ItemType Directory -Force ".\applications\micro_simulator" | Out-Null
Copy-Item -Recurse -Force "$PackageRoot\applications\micro_simulator\*" ".\applications\micro_simulator\"

Write-Host "Created clean application at $Workspace\applications\micro_simulator"
Write-Host "Build with:"
Write-Host "west build --sysbuild -b nrf9151dk/nrf9151/ns -s applications\micro_simulator -d $BuildDir --pristine=always"
Write-Host "Flash with:"
Write-Host "west flash -d $BuildDir"
