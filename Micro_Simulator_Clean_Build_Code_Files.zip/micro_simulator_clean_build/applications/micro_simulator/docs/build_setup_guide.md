# Micro Simulator Clean Build Guide

## Goal

Create a clean `micro_simulator` Zephyr application inside the existing Onomondo SoftSIM workspace while keeping the Onomondo SoftSIM SDK/module setup intact.

This guide assumes the Onomondo workspace already exists at:

```text
C:\Users\amiri\onomondo-softsim-test
```

Do not delete the workspace root. Do not delete:

```text
C:\Users\amiri\onomondo-softsim-test\modules\lib\onomondo-softsim
C:\ss
```

The first path contains the Onomondo SoftSIM module. The second path contains your SoftSIM CLI, private key, encrypted profile folder, and generated `profile_001.hex`.

---

## Clean slate rule

You may delete the application and build output:

```text
C:\Users\amiri\onomondo-softsim-test\applications\micro_simulator
C:\b\micro_sim_clean
```

You should not delete:

```text
C:\Users\amiri\onomondo-softsim-test\.west
C:\Users\amiri\onomondo-softsim-test\nrf
C:\Users\amiri\onomondo-softsim-test\zephyr
C:\Users\amiri\onomondo-softsim-test\modules
C:\ss
```

---

## Folder structure to create

```text
C:\Users\amiri\onomondo-softsim-test\applications\micro_simulator
│   CMakeLists.txt
│   prj.conf
│   sysbuild.conf
│
├───src
│       main.c
│
└───docs
        build_setup_guide.md
        serial_commands.md
```

---

## PowerShell clean setup commands

Run these from an nRF Connect SDK terminal or a PowerShell terminal that can run `west`.

```powershell
cd C:\Users\amiri\onomondo-softsim-test

Remove-Item Env:ZEPHYR_BASE -ErrorAction SilentlyContinue

# Delete only the simulator app and build output.
Remove-Item -Recurse -Force .\applications\micro_simulator -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force C:\b\micro_sim_clean -ErrorAction SilentlyContinue

# Recreate the clean application folder.
New-Item -ItemType Directory -Force .\applications\micro_simulator\src
New-Item -ItemType Directory -Force .\applications\micro_simulator\docs
```

Then copy the provided files into the new folder:

```text
CMakeLists.txt  -> applications\micro_simulator\CMakeLists.txt
prj.conf        -> applications\micro_simulator\prj.conf
sysbuild.conf   -> applications\micro_simulator\sysbuild.conf
main.c          -> applications\micro_simulator\src\main.c
*.md docs       -> applications\micro_simulator\docs\
```

Before building, verify that `main.c` is actual C code and not Markdown:

```powershell
Get-Content .\applications\micro_simulator\src\main.c -TotalCount 5
```

Good output starts with a C comment or `#include`. Bad output starts with `# Micro Simulator...`.

---

## Build command

Use a short build path to avoid Windows path length problems:

```powershell
cd C:\Users\amiri\onomondo-softsim-test

west build --sysbuild -b nrf9151dk/nrf9151/ns -s applications\micro_simulator -d C:\b\micro_sim_clean --pristine=always
```

---

## Flash command

```powershell
west flash -d C:\b\micro_sim_clean
```

Use normal flash. Do not use recover/full erase unless you intentionally want to wipe the board.

---

## Expected first boot

If the SoftSIM profile is not currently detected, the board prints:

```text
Transfer SoftSIM profile using serial COM port, terminate by newline character (return key)
```

Copy the existing generated profile:

```powershell
cd C:\ss
$profile = (Get-Content .\profile_001.hex -Raw).Trim()
Set-Clipboard -Value $profile
```

Paste it into the nRF serial terminal and press Enter.

The pasted HEX string may not visibly appear. That is normal.

After provisioning, the board reboots. Then it should attach to LTE and show the CLI.

---

## Expected successful runtime

```text
Micro serial simulator started
Waiting for LTE connect event
Network registration status: Connected - roaming
LTE connected
Serial CLI ready. Type: help
Recommended first command: connect 137.184.163.176 5000
micro>
```

---

## First commands

```text
help
connect 137.184.163.176 5000
mode ascii_hex
send sample_hb_beacon
send sample_hb_gps
send sample_location
status
```

---

## Why this build includes SoftSIM

`CMakeLists.txt` adds the Onomondo SoftSIM overlay from:

```text
modules/lib/onomondo-softsim/overlay-softsim.conf
```

`sysbuild.conf` includes:

```text
SB_CONFIG_SOFTSIM_BUNDLE_TEMPLATE_HEX=y
```

This bundles the SoftSIM template flash data with the sysbuild image.

---

## Common build failure

If the compiler says:

```text
invalid preprocessing directive #Micro
stray '##' in program
stray '`' in program
```

then Markdown documentation was pasted into `src/main.c`. Replace `src/main.c` with the actual C source file.


## NCS version compatibility note

This clean-build package intentionally does not reference `LTE_LC_EVT_PSM_UPDATE` or `evt->psm_cfg` in `main.c`. Some nRF Connect SDK versions expose PSM events differently, and some builds do not define `LTE_LC_EVT_PSM_UPDATE` at all. The simulator does not need PSM event details, so those logs are omitted for maximum build compatibility.

## v4 SoftSIM provisioning note

The firmware accepts the SoftSIM profile as HEX text. Whitespace and line breaks are ignored. After pasting the complete profile, wait about 3 seconds. The firmware will automatically stop collecting input and call `nrf_softsim_provision()`.

If provisioning fails and the log says fewer characters than expected, the paste was truncated or the serial terminal inserted a line break. Paste the full content of `C:\ss\profile_001.hex` again. The firmware will re-prompt instead of exiting.

## Runtime UART callback error

If the board boots and prints:

```text
Failed to set UART callback: -134
```

then the UART interrupt-driven API is not enabled for the application. The serial input path uses `uart_irq_callback_user_data_set()` so that long SoftSIM profile pastes are received reliably. Add this to `applications\micro_simulator\prj.conf`:

```conf
CONFIG_UART_INTERRUPT_DRIVEN=y
```

Then rebuild with `--pristine=always` and flash again.


## Quiet SoftSIM logs

The simulator keeps application logs at INFO, but keeps SoftSIM/UICC internals at warning level to avoid hundreds of serial log lines and `messages dropped` notices during SIM APDU exchange. This is controlled in `prj.conf` by:

```conf
CONFIG_LOG_DEFAULT_LEVEL=2
CONFIG_SOFTSIM_NRF_DEBUG_LOGS=n
CONFIG_SOFTSIM_LIBS_DEBUG_LOGS=n
CONFIG_LOG_BUFFER_SIZE=4096
```

For deep SoftSIM debugging, temporarily set the two SoftSIM debug symbols to `y` and increase the log buffer. Return them to `n` for normal simulator work.
