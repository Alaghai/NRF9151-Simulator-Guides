# Micro Simulator Serial Commands

## Startup sequence

1. Flash the firmware.
2. Open the nRF serial terminal.
3. Paste the SoftSIM HEX profile if prompted.
4. Wait for LTE connection.
5. Connect to the TCP server.
6. Send sample or dynamic packets.

## Connection commands

```text
help
status
connect
connect <PUBLIC_IPV4> <PORT>
disconnect
recv
```

Example:

```text
connect 137.184.163.176 5000
```

## Send modes

```text
mode ascii_hex
mode binary
```

Use `ascii_hex` first. It sends readable hex characters. Use `binary` later when the backend parser expects raw bytes.

## Exact sample packets

```text
send sample_hb_beacon
send sample_hb_gps
send sample_location
```

These send the exact sample strings from the protocol document.

## Dynamic packets

```text
send hb
send loc
```

These build packets from the current simulator fields. CRC is a placeholder until the final CRC algorithm is confirmed.

## Raw packet injection

```text
send raw <HEX_STRING>
```

Example:

```text
send raw AB102500D5E6230138363133353230363430353037383719EDB8266D50000000001007FF0101010FAC91003B91
```

## Presets

```text
preset normal
preset low
preset charging
preset outside
preset beacon
preset trusted
```

## Field updates

```text
set battery low
set battery medium
set battery high
set charging on
set charging off
set opcode beacon
set opcode trusted
set opcode gps_lte
set opcode gps_safezone
set pos 45.4215 -75.6972 25.5 0.0
set imei 861352064050787
set lastupdate 2047
set versions 1 1
set beacon 0FAC91003B91
set trusted AABBCCDDEE01
```

## Copy-paste test flows

Basic bring-up:

```text
connect 137.184.163.176 5000
mode ascii_hex
send sample_hb_beacon
send sample_hb_gps
send sample_location
status
```

Low battery:

```text
preset low
send hb
```

Outside safe-zone style update:

```text
preset outside
send hb
send loc
```

Custom location:

```text
set pos 45.4215 -75.6972 25.5 0.0
set opcode gps_lte
send hb
send loc
```

