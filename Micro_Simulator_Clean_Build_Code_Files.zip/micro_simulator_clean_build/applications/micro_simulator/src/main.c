/*
 * Micro serial-controlled simulator for nRF9151 DK + Onomondo SoftSIM.
 *
 * Clean-slate application goals:
 * - Keep Onomondo external SoftSIM provisioning over serial.
 * - Attach to LTE-M through the provisioned SoftSIM.
 * - Let the user choose a TCP server from the serial terminal.
 * - Keep the TCP socket open after connect.
 * - Send Micro heartbeat/location packets on command.
 * - Print server responses when available.
 *
 * IMPORTANT:
 * Dynamic packets use placeholder CRC because the final CRC divider is not finalized.
 * Use the sample_* commands first for backend bring-up because those transmit exact
 * sample packet strings from the current protocol document.
 */

#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/logging/log_ctrl.h>
#include <zephyr/net/socket.h>
#include <zephyr/sys/reboot.h>
#include <zephyr/sys/util.h>

#include <modem/lte_lc.h>
#include <modem/nrf_modem_lib.h>

#include <nrf_softsim.h>

LOG_MODULE_REGISTER(micro_simulator, LOG_LEVEL_INF);

#define DEFAULT_SERVER_IP "137.184.163.176"
#define DEFAULT_SERVER_PORT 5000
#define DEFAULT_IMEI "861352064050787"

/* Coordinate scaling used by this simulator for dynamic packets.
 * The protocol text says /100000, while the sample bytes appear consistent
 * with /1000000. Default to 1000000 for better decimal-degree precision.
 */
#define MICRO_COORD_SCALE 1000000

#define PROFILE_MAX_SIZE 1024
#define PROFILE_IDLE_DONE_MS 2500
#define CLI_LINE_MAX 256
#define MAX_PACKET_BYTES 160
#define MAX_HEX_CHARS ((MAX_PACKET_BYTES * 2) + 1)
#define SERVER_RESPONSE_MAX 256

#define TCP_RECV_POLL_MS 1000

K_SEM_DEFINE(lte_connected, 0, 1);

static const struct device *const uart_dev = DEVICE_DT_GET(DT_NODELABEL(uart0));

/* Exact sample packets from the current Micro protocol document. */
static const char SAMPLE_HB_BEACON[] =
    "AB102500D5E6230138363133353230363430353037383719EDB8266D50000000001007FF0101010FAC91003B91";

static const char SAMPLE_HB_GPS[] =
    "AB101E00D5E6230138363133353230363430353037383719EDB8266D50000000001007FF010110FAA2B580F5456B0000FF00FF";

static const char SAMPLE_LOCATION[] =
    "AB10100026A1B2B50F1038363133353230363430353037383700506D26B8ED1900007FFFFAA2B580F5456B000FFF0FFF";

static const uint8_t SAMPLE_TIMESTAMP_8[8] = {
    0x19, 0xED, 0xB8, 0x26, 0x6D, 0x50, 0x00, 0x00
};

static const uint8_t SAMPLE_TIMESTAMP_9[9] = {
    0x19, 0xED, 0xB8, 0x26, 0x6D, 0x50, 0x00, 0x00, 0x00
};

enum wire_mode {
    WIRE_ASCII_HEX = 0,
    WIRE_BINARY = 1,
};

enum heartbeat_opcode {
    OPCODE_BEACON = 0x01,
    OPCODE_GPS_SAFEZONE = 0x0A,
    OPCODE_GPS_LTE = 0x10,
    OPCODE_TRUSTED = 0xA0,
};

struct sim_state {
    char server_ip[16];
    uint16_t server_port;
    int tcp_fd;
    bool tcp_connected;
    enum wire_mode mode;

    uint16_t sequence_id;
    char imei[17];

    uint8_t battery;      /* 0x00 low, 0x01 medium, 0x10 high */
    uint8_t charging;     /* 0x01 not charging, 0x10 charging */
    uint16_t last_update; /* minutes */
    uint8_t sw_version;
    uint8_t fw_version;
    uint8_t opcode;

    int32_t lat_e6;
    int32_t lon_e6;
    uint16_t accuracy_x10;
    uint16_t speed_x10;

    uint8_t beacon_mac[6];
    uint8_t trusted_addr[6];
};

static struct sim_state state = {
    .server_ip = DEFAULT_SERVER_IP,
    .server_port = DEFAULT_SERVER_PORT,
    .tcp_fd = -1,
    .tcp_connected = false,
    .mode = WIRE_ASCII_HEX,
    .sequence_id = 1,
    .imei = DEFAULT_IMEI,
    .battery = 0x01,
    .charging = 0x01,
    .last_update = 2047,
    .sw_version = 1,
    .fw_version = 1,
    .opcode = OPCODE_BEACON,
    .lat_e6 = 45421500,
    .lon_e6 = -75697200,
    .accuracy_x10 = 255,
    .speed_x10 = 0,
    .beacon_mac = {0x0F, 0xAC, 0x91, 0x00, 0x3B, 0x91},
    .trusted_addr = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0x01},
};

/* Forward declarations. Keep these above provisioning code because C99 does not
 * allow implicit function declarations, and Zephyr builds with strict flags.
 */
static int hex_nibble(char c);
static int hex_to_bytes(const char *hex, uint8_t *out, size_t out_max, size_t *out_len);
static void bytes_to_hex(const uint8_t *bytes, size_t len, char *hex, size_t hex_len);
static void tcp_disconnect(void);
static int tcp_connect_to_server(const char *ip, uint16_t port);
static int tcp_recv_response(void);
static int tcp_send_hex_payload(const char *hex);


static void drain_logs_and_reboot(void)
{
    while (log_data_pending()) {
        log_process();
        k_yield();
    }

    sys_reboot(0);
}


/* -------------------------------------------------------------------------- */
/* Robust serial input                                                        */
/* -------------------------------------------------------------------------- */

/*
 * Use UART interrupt input instead of polling.
 * Polling can miss bytes when a full SoftSIM profile is pasted quickly from a
 * terminal. The previous working firmware used interrupt-driven input, so this
 * version keeps that behavior for both SoftSIM provisioning and the CLI.
 */
K_MSGQ_DEFINE(serial_char_msgq, sizeof(uint8_t), 2048, 4);

static void serial_uart_cb(const struct device *dev, void *user_data)
{
    ARG_UNUSED(user_data);

    if (!uart_irq_update(dev)) {
        return;
    }

    while (uart_irq_rx_ready(dev)) {
        uint8_t c;
        int rx = uart_fifo_read(dev, &c, 1);

        if (rx <= 0) {
            return;
        }

        (void)k_msgq_put(&serial_char_msgq, &c, K_NO_WAIT);
    }
}

static int serial_input_start(void)
{
    if (!device_is_ready(uart_dev)) {
        LOG_ERR("UART device not ready");
        return -ENODEV;
    }

    int err = uart_irq_callback_user_data_set(uart_dev, serial_uart_cb, NULL);
    if (err) {
        LOG_ERR("Failed to set UART callback: %d", err);
        return err;
    }

    uart_irq_rx_enable(uart_dev);
    return 0;
}

static int serial_get_char(uint8_t *c, k_timeout_t timeout)
{
    return k_msgq_get(&serial_char_msgq, c, timeout);
}

static int read_line_serial(char *buf, size_t buf_len, bool echo)
{
    size_t pos = 0;

    if (buf_len == 0) {
        return -EINVAL;
    }

    memset(buf, 0, buf_len);

    while (true) {
        uint8_t c;
        int err = serial_get_char(&c, K_FOREVER);
        if (err) {
            return err;
        }

        if (c == '\r' || c == '\n') {
            if (echo) {
                printk("\r\n");
            }
            buf[pos] = '\0';
            return (int)pos;
        }

        if (c == 0x08 || c == 0x7F) {
            if (pos > 0) {
                pos--;
                buf[pos] = '\0';
                if (echo) {
                    printk("\b \b");
                }
            }
            continue;
        }

        if (pos < buf_len - 1) {
            buf[pos++] = (char)c;
            if (echo) {
                uart_poll_out(uart_dev, c);
            }
        }
    }
}

static int read_softsim_profile(char *buf, size_t buf_len)
{
    size_t pos = 0;
    bool started = false;
    size_t visible_count = 0;

    if (buf_len == 0) {
        return -EINVAL;
    }

    memset(buf, 0, buf_len);

    while (true) {
        uint8_t c;
        k_timeout_t timeout = started ? K_MSEC(PROFILE_IDLE_DONE_MS) : K_FOREVER;
        int err = serial_get_char(&c, timeout);

        if (err == -EAGAIN) {
            if (started) {
                buf[pos] = '\0';
                printk("\r\n");
                return (int)pos;
            }
            continue;
        }

        if (err) {
            return err;
        }

        if (c == '\r' || c == '\n' || c == ' ' || c == '\t') {
            /* Ignore whitespace so profiles copied with wrapping still work. */
            continue;
        }

        if (hex_nibble((char)c) < 0) {
            printk("\r\nInvalid non-hex character received: 0x%02X\r\n", c);
            return -EINVAL;
        }

        started = true;

        if (pos >= buf_len - 1) {
            printk("\r\nSoftSIM profile too long for buffer\r\n");
            return -ENOMEM;
        }

        buf[pos++] = (char)c;

        /* Progress indicator without printing the secret profile. */
        visible_count++;
        if ((visible_count % 64) == 0) {
            printk(".");
        }
    }
}

static int provision_softsim_from_serial(void)
{
    if (!device_is_ready(uart_dev)) {
        LOG_ERR("UART device not ready");
        return -ENODEV;
    }

    char profile[PROFILE_MAX_SIZE];

    LOG_INF("Transfer SoftSIM profile using serial COM port.");
    LOG_INF("Paste the complete HEX profile. Whitespace and line breaks are ignored.");
    LOG_INF("After paste, wait about 3 seconds; the firmware will provision automatically.");

    int len = read_softsim_profile(profile, sizeof(profile));
    if (len <= 0) {
        LOG_ERR("Invalid SoftSIM profile length: %d", len);
        return -EINVAL;
    }

    LOG_INF("Profile received: %d hex characters in total", len);

    if ((len % 2) != 0) {
        LOG_ERR("SoftSIM profile has odd hex character count; profile is incomplete");
        return -EINVAL;
    }

    int err = nrf_softsim_provision((uint8_t *)profile, (size_t)len);
    if (err != 0) {
        LOG_ERR("SoftSIM profile provisioning failed: %d", err);
        LOG_ERR("Most common cause: only part of the profile was pasted or the profile contains extra text.");
        return err;
    }

    LOG_INF("SoftSIM provisioned; rebooting");
    drain_logs_and_reboot();

    return 0;
}

static void lte_handler(const struct lte_lc_evt *const evt)
{
    switch (evt->type) {
    case LTE_LC_EVT_NW_REG_STATUS:
        if ((evt->nw_reg_status == LTE_LC_NW_REG_REGISTERED_HOME) ||
            (evt->nw_reg_status == LTE_LC_NW_REG_REGISTERED_ROAMING)) {
            LOG_INF("Network registration status: %s",
                evt->nw_reg_status == LTE_LC_NW_REG_REGISTERED_HOME ?
                "Connected - home network" : "Connected - roaming");
            k_sem_give(&lte_connected);
        }
        break;

    case LTE_LC_EVT_RRC_UPDATE:
        LOG_INF("RRC mode: %s",
            evt->rrc_mode == LTE_LC_RRC_MODE_CONNECTED ? "Connected" : "Idle");
        break;

    case LTE_LC_EVT_CELL_UPDATE:
        LOG_INF("LTE cell changed: Cell ID: %d, Tracking area: %d",
            evt->cell.id, evt->cell.tac);
        break;

    default:
        break;
    }
}

static int modem_connect(void)
{
    int err = lte_lc_connect_async(lte_handler);
    if (err) {
        LOG_ERR("Connecting to LTE network failed: %d", err);
        return err;
    }

    LOG_INF("Waiting for LTE connect event");
    while (k_sem_take(&lte_connected, K_SECONDS(10)) != 0) {
        LOG_INF("Still waiting for LTE...");
    }

    LOG_INF("LTE connected");
    return 0;
}

static int hex_nibble(char c)
{
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'a' && c <= 'f') {
        return c - 'a' + 10;
    }
    if (c >= 'A' && c <= 'F') {
        return c - 'A' + 10;
    }
    return -1;
}

static int hex_to_bytes(const char *hex, uint8_t *out, size_t out_max, size_t *out_len)
{
    int high = -1;
    size_t len = 0;

    for (size_t i = 0; hex[i] != '\0'; i++) {
        if (isspace((unsigned char)hex[i])) {
            continue;
        }

        int n = hex_nibble(hex[i]);
        if (n < 0) {
            return -EINVAL;
        }

        if (high < 0) {
            high = n;
        } else {
            if (len >= out_max) {
                return -ENOMEM;
            }
            out[len++] = (uint8_t)((high << 4) | n);
            high = -1;
        }
    }

    if (high >= 0) {
        return -EINVAL;
    }

    *out_len = len;
    return 0;
}

static void bytes_to_hex(const uint8_t *bytes, size_t len, char *hex, size_t hex_len)
{
    static const char digits[] = "0123456789ABCDEF";

    if (hex_len < (len * 2) + 1) {
        if (hex_len > 0) {
            hex[0] = '\0';
        }
        return;
    }

    for (size_t i = 0; i < len; i++) {
        hex[i * 2] = digits[(bytes[i] >> 4) & 0x0F];
        hex[(i * 2) + 1] = digits[bytes[i] & 0x0F];
    }
    hex[len * 2] = '\0';
}

static void append_u8(uint8_t *buf, size_t *len, uint8_t v)
{
    buf[(*len)++] = v;
}

static void append_u16_be(uint8_t *buf, size_t *len, uint16_t v)
{
    buf[(*len)++] = (uint8_t)((v >> 8) & 0xFF);
    buf[(*len)++] = (uint8_t)(v & 0xFF);
}

static void append_i32_be(uint8_t *buf, size_t *len, int32_t v)
{
    uint32_t u = (uint32_t)v;
    buf[(*len)++] = (uint8_t)((u >> 24) & 0xFF);
    buf[(*len)++] = (uint8_t)((u >> 16) & 0xFF);
    buf[(*len)++] = (uint8_t)((u >> 8) & 0xFF);
    buf[(*len)++] = (uint8_t)(u & 0xFF);
}

static void append_bytes(uint8_t *buf, size_t *len, const uint8_t *src, size_t src_len)
{
    memcpy(&buf[*len], src, src_len);
    *len += src_len;
}

static void append_imei(uint8_t *buf, size_t *len)
{
    /* Protocol document states 16 bytes but examples show 15 ASCII digits.
     * Use 15 ASCII digits to match current example strings.
     */
    size_t imei_len = strlen(state.imei);
    if (imei_len > 15) {
        imei_len = 15;
    }
    append_bytes(buf, len, (const uint8_t *)state.imei, imei_len);
}

static int32_t coord_for_protocol(int32_t e6)
{
#if MICRO_COORD_SCALE == 1000000
    return e6;
#elif MICRO_COORD_SCALE == 100000
    return e6 / 10;
#else
#error "Unsupported MICRO_COORD_SCALE"
#endif
}

static void append_location_fields(uint8_t *buf, size_t *len)
{
    append_i32_be(buf, len, coord_for_protocol(state.lat_e6));
    append_i32_be(buf, len, coord_for_protocol(state.lon_e6));
    append_u16_be(buf, len, state.accuracy_x10);
    append_u16_be(buf, len, state.speed_x10);
}

static void start_packet(uint8_t *buf, size_t *len, uint8_t command)
{
    *len = 0;
    append_u8(buf, len, 0xAB);          /* Header */
    append_u8(buf, len, 0x10);          /* Property */
    append_u8(buf, len, 0x00);          /* Length placeholder, low */
    append_u8(buf, len, 0x00);          /* Length placeholder, high */
    append_u8(buf, len, 0xD5);          /* Placeholder CRC byte 0 */
    append_u8(buf, len, 0x00);          /* Placeholder CRC byte 1 */
    append_u8(buf, len, (uint8_t)(state.sequence_id & 0xFF));
    append_u8(buf, len, (uint8_t)((state.sequence_id >> 8) & 0xFF));
    append_u8(buf, len, command);
}

static void finish_packet_length(uint8_t *buf, size_t len)
{
    /* Simulator length convention: bytes after the 2-byte Length field.
     * This includes placeholder CRC, sequence ID, command, and payload.
     * Backend should not treat this as final until CRC/length definitions are frozen.
     */
    uint16_t body_len = (uint16_t)(len - 4);
    buf[2] = (uint8_t)(body_len & 0xFF);
    buf[3] = (uint8_t)((body_len >> 8) & 0xFF);
}

static int build_heartbeat_hex(char *hex, size_t hex_len)
{
    uint8_t pkt[MAX_PACKET_BYTES];
    size_t len;

    start_packet(pkt, &len, 0x01);
    append_imei(pkt, &len);
    append_bytes(pkt, &len, SAMPLE_TIMESTAMP_8, sizeof(SAMPLE_TIMESTAMP_8));
    append_u8(pkt, &len, state.battery);
    append_u8(pkt, &len, state.charging);
    append_u16_be(pkt, &len, state.last_update);
    append_u8(pkt, &len, state.sw_version);
    append_u8(pkt, &len, state.fw_version);
    append_u8(pkt, &len, state.opcode);

    if (state.opcode == OPCODE_BEACON) {
        append_bytes(pkt, &len, state.beacon_mac, sizeof(state.beacon_mac));
    } else if (state.opcode == OPCODE_TRUSTED) {
        append_bytes(pkt, &len, state.trusted_addr, sizeof(state.trusted_addr));
    } else {
        append_location_fields(pkt, &len);
    }

    finish_packet_length(pkt, len);
    bytes_to_hex(pkt, len, hex, hex_len);
    state.sequence_id++;

    return 0;
}

static int build_location_hex(char *hex, size_t hex_len)
{
    uint8_t pkt[MAX_PACKET_BYTES];
    size_t len;

    start_packet(pkt, &len, 0x10);
    append_imei(pkt, &len);
    append_bytes(pkt, &len, SAMPLE_TIMESTAMP_9, sizeof(SAMPLE_TIMESTAMP_9));
    append_u8(pkt, &len, state.battery);
    append_u8(pkt, &len, state.charging);
    append_u16_be(pkt, &len, state.last_update);
    append_location_fields(pkt, &len);

    finish_packet_length(pkt, len);
    bytes_to_hex(pkt, len, hex, hex_len);
    state.sequence_id++;

    return 0;
}

static void tcp_disconnect(void)
{
    if (state.tcp_fd >= 0) {
        zsock_close(state.tcp_fd);
    }
    state.tcp_fd = -1;
    state.tcp_connected = false;
    printk("TCP disconnected\r\n");
}

static int tcp_connect_to_server(const char *ip, uint16_t port)
{
    struct sockaddr_in server4;

    if (state.tcp_connected) {
        tcp_disconnect();
    }

    memset(&server4, 0, sizeof(server4));
    server4.sin_family = AF_INET;
    server4.sin_port = htons(port);

    if (zsock_inet_pton(AF_INET, ip, &server4.sin_addr) != 1) {
        printk("Invalid IPv4 address: %s\r\n", ip);
        return -EINVAL;
    }

    int fd = zsock_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd < 0) {
        printk("TCP socket create failed: errno=%d\r\n", errno);
        return -errno;
    }

    printk("Connecting to %s:%u ...\r\n", ip, port);

    if (zsock_connect(fd, (struct sockaddr *)&server4, sizeof(server4)) < 0) {
        int err = -errno;
        printk("TCP connect failed: errno=%d\r\n", errno);
        zsock_close(fd);
        return err;
    }

    state.tcp_fd = fd;
    state.tcp_connected = true;
    strncpy(state.server_ip, ip, sizeof(state.server_ip) - 1);
    state.server_ip[sizeof(state.server_ip) - 1] = '\0';
    state.server_port = port;

    printk("TCP connected to %s:%u\r\n", state.server_ip, state.server_port);
    return 0;
}

static int tcp_recv_response(void)
{
    if (!state.tcp_connected || state.tcp_fd < 0) {
        printk("TCP not connected\r\n");
        return -ENOTCONN;
    }

    struct zsock_pollfd pfd = {
        .fd = state.tcp_fd,
        .events = ZSOCK_POLLIN,
        .revents = 0,
    };

    int pr = zsock_poll(&pfd, 1, TCP_RECV_POLL_MS);
    if (pr == 0) {
        printk("No server response within %d ms\r\n", TCP_RECV_POLL_MS);
        return 0;
    }
    if (pr < 0) {
        printk("poll failed: errno=%d\r\n", errno);
        return -errno;
    }

    uint8_t resp[SERVER_RESPONSE_MAX];
    ssize_t n = zsock_recv(state.tcp_fd, resp, sizeof(resp) - 1, 0);
    if (n == 0) {
        printk("Server closed TCP socket\r\n");
        tcp_disconnect();
        return -ECONNRESET;
    }
    if (n < 0) {
        printk("TCP recv failed: errno=%d\r\n", errno);
        return -errno;
    }

    resp[n] = 0;

    printk("Server response (%d bytes): ", (int)n);
    bool printable = true;
    for (ssize_t i = 0; i < n; i++) {
        if ((resp[i] < 0x20 || resp[i] > 0x7E) && resp[i] != '\r' && resp[i] != '\n') {
            printable = false;
            break;
        }
    }

    if (printable) {
        printk("%s\r\n", resp);
    } else {
        for (ssize_t i = 0; i < n; i++) {
            printk("%02X", resp[i]);
        }
        printk("\r\n");
    }

    return 0;
}

static int tcp_send_hex_payload(const char *hex)
{
    if (!state.tcp_connected || state.tcp_fd < 0) {
        printk("TCP not connected. Use: connect <ip> <port>\r\n");
        return -ENOTCONN;
    }

    uint8_t bin[MAX_PACKET_BYTES];
    size_t bin_len = 0;
    int err = hex_to_bytes(hex, bin, sizeof(bin), &bin_len);
    if (err) {
        printk("Invalid hex string; error=%d\r\n", err);
        return err;
    }

    if (state.mode == WIRE_ASCII_HEX) {
        size_t len = strlen(hex);
        const char *p = hex;
        while (len > 0) {
            ssize_t n = zsock_send(state.tcp_fd, p, len, 0);
            if (n < 0) {
                printk("TCP send failed: errno=%d\r\n", errno);
                tcp_disconnect();
                return -errno;
            }
            p += n;
            len -= (size_t)n;
        }
        printk("Sent ASCII hex (%u chars)\r\n", (unsigned int)strlen(hex));
    } else {
        size_t remaining = bin_len;
        uint8_t *p = bin;
        while (remaining > 0) {
            ssize_t n = zsock_send(state.tcp_fd, p, remaining, 0);
            if (n < 0) {
                printk("TCP send failed: errno=%d\r\n", errno);
                tcp_disconnect();
                return -errno;
            }
            p += n;
            remaining -= (size_t)n;
        }
        printk("Sent binary packet (%u bytes)\r\n", (unsigned int)bin_len);
    }

    tcp_recv_response();
    return 0;
}

static int parse_scaled_i32(const char *s, int32_t scale, int32_t *out)
{
    bool neg = false;
    int64_t whole = 0;
    int64_t frac = 0;
    int64_t frac_scale = 1;
    const char *p = s;

    if (*p == '-') {
        neg = true;
        p++;
    } else if (*p == '+') {
        p++;
    }

    if (!isdigit((unsigned char)*p)) {
        return -EINVAL;
    }

    while (isdigit((unsigned char)*p)) {
        whole = (whole * 10) + (*p - '0');
        p++;
    }

    if (*p == '.') {
        p++;
        while (isdigit((unsigned char)*p) && frac_scale < scale) {
            frac = (frac * 10) + (*p - '0');
            frac_scale *= 10;
            p++;
        }
        while (isdigit((unsigned char)*p)) {
            p++;
        }
    }

    if (*p != '\0') {
        return -EINVAL;
    }

    int64_t value = (whole * scale) + ((frac * scale) / frac_scale);
    if (neg) {
        value = -value;
    }

    if (value > INT32_MAX || value < INT32_MIN) {
        return -ERANGE;
    }

    *out = (int32_t)value;
    return 0;
}

static int parse_u16(const char *s, uint16_t *out)
{
    char *end = NULL;
    long v = strtol(s, &end, 10);
    if (end == s || *end != '\0' || v < 0 || v > 65535) {
        return -EINVAL;
    }
    *out = (uint16_t)v;
    return 0;
}

static int parse_u8(const char *s, uint8_t *out)
{
    uint16_t tmp;
    int err = parse_u16(s, &tmp);
    if (err || tmp > 255) {
        return -EINVAL;
    }
    *out = (uint8_t)tmp;
    return 0;
}

static int parse_hex6(const char *s, uint8_t out[6])
{
    size_t len = strlen(s);
    if (len != 12) {
        return -EINVAL;
    }

    for (size_t i = 0; i < 6; i++) {
        int hi = hex_nibble(s[i * 2]);
        int lo = hex_nibble(s[(i * 2) + 1]);
        if (hi < 0 || lo < 0) {
            return -EINVAL;
        }
        out[i] = (uint8_t)((hi << 4) | lo);
    }

    return 0;
}

static const char *mode_name(void)
{
    return state.mode == WIRE_ASCII_HEX ? "ascii_hex" : "binary";
}

static const char *opcode_name(uint8_t opcode)
{
    switch (opcode) {
    case OPCODE_BEACON: return "beacon";
    case OPCODE_GPS_SAFEZONE: return "gps_safezone";
    case OPCODE_GPS_LTE: return "gps_lte";
    case OPCODE_TRUSTED: return "trusted";
    default: return "unknown";
    }
}

static void print_help(void)
{
    printk("\r\nMicro simulator commands:\r\n");
    printk("  help\r\n");
    printk("  status\r\n");
    printk("  connect [ip] [port]\r\n");
    printk("  disconnect\r\n");
    printk("  recv\r\n");
    printk("  mode ascii_hex|binary\r\n");
    printk("  send sample_hb_beacon\r\n");
    printk("  send sample_hb_gps\r\n");
    printk("  send sample_location\r\n");
    printk("  send hb\r\n");
    printk("  send loc\r\n");
    printk("  send raw <HEX>\r\n");
    printk("  preset normal|low|charging|outside|beacon|trusted\r\n");
    printk("  set battery low|medium|high\r\n");
    printk("  set charging on|off\r\n");
    printk("  set opcode beacon|trusted|gps_lte|gps_safezone\r\n");
    printk("  set pos <lat> <lon> <accuracy_m> <speed_mps>\r\n");
    printk("  set imei <digits>\r\n");
    printk("  set lastupdate <minutes>\r\n");
    printk("  set versions <sw> <fw>\r\n");
    printk("  set beacon <12_hex_chars>\r\n");
    printk("  set trusted <12_hex_chars>\r\n\r\n");
}

static void print_hex6(const uint8_t v[6])
{
    for (size_t i = 0; i < 6; i++) {
        printk("%02X", v[i]);
    }
}

static void print_status(void)
{
    printk("\r\nStatus:\r\n");
    printk("  TCP: %s %s:%u\r\n", state.tcp_connected ? "connected" : "disconnected",
        state.server_ip, state.server_port);
    printk("  mode: %s\r\n", mode_name());
    printk("  sequence_id: %u\r\n", state.sequence_id);
    printk("  imei: %s\r\n", state.imei);
    printk("  battery: 0x%02X\r\n", state.battery);
    printk("  charging: 0x%02X\r\n", state.charging);
    printk("  last_update: %u minutes\r\n", state.last_update);
    printk("  versions: sw=%u fw=%u\r\n", state.sw_version, state.fw_version);
    printk("  opcode: 0x%02X (%s)\r\n", state.opcode, opcode_name(state.opcode));
    printk("  lat_e6: %d lon_e6: %d\r\n", state.lat_e6, state.lon_e6);
    printk("  accuracy_x10: %u speed_x10: %u\r\n", state.accuracy_x10, state.speed_x10);
    printk("  beacon: "); print_hex6(state.beacon_mac); printk("\r\n");
    printk("  trusted: "); print_hex6(state.trusted_addr); printk("\r\n\r\n");
}

static void apply_preset(const char *preset)
{
    if (strcmp(preset, "normal") == 0) {
        state.battery = 0x01;
        state.charging = 0x01;
        state.opcode = OPCODE_BEACON;
    } else if (strcmp(preset, "low") == 0) {
        state.battery = 0x00;
        state.charging = 0x01;
    } else if (strcmp(preset, "charging") == 0) {
        state.battery = 0x01;
        state.charging = 0x10;
    } else if (strcmp(preset, "outside") == 0) {
        state.opcode = OPCODE_GPS_LTE;
        state.lat_e6 = 45450000;
        state.lon_e6 = -75750000;
        state.accuracy_x10 = 300;
        state.speed_x10 = 12;
    } else if (strcmp(preset, "beacon") == 0) {
        state.opcode = OPCODE_BEACON;
    } else if (strcmp(preset, "trusted") == 0) {
        state.opcode = OPCODE_TRUSTED;
    } else {
        printk("Unknown preset: %s\r\n", preset);
        return;
    }

    printk("Applied preset: %s\r\n", preset);
}

static char *trim_left(char *s)
{
    while (s && isspace((unsigned char)*s)) {
        s++;
    }
    return s;
}

static void split_first(char *line, char **first, char **rest)
{
    line = trim_left(line);
    *first = line;
    *rest = NULL;

    if (line == NULL || line[0] == '\0') {
        *first = NULL;
        return;
    }

    char *space = line;
    while (*space != '\0' && !isspace((unsigned char)*space)) {
        space++;
    }

    if (*space != '\0') {
        *space = '\0';
        *rest = trim_left(space + 1);
    }
}

static void handle_send_command(char *args)
{
    char *what = NULL;
    char *rest = NULL;
    char hex[MAX_HEX_CHARS];

    split_first(args, &what, &rest);

    if (what == NULL) {
        printk("Usage: send <sample_hb_beacon|sample_hb_gps|sample_location|hb|loc|raw>\r\n");
        return;
    }

    if (strcmp(what, "sample_hb_beacon") == 0) {
        tcp_send_hex_payload(SAMPLE_HB_BEACON);
    } else if (strcmp(what, "sample_hb_gps") == 0) {
        tcp_send_hex_payload(SAMPLE_HB_GPS);
    } else if (strcmp(what, "sample_location") == 0) {
        tcp_send_hex_payload(SAMPLE_LOCATION);
    } else if (strcmp(what, "hb") == 0) {
        build_heartbeat_hex(hex, sizeof(hex));
        printk("Dynamic heartbeat hex: %s\r\n", hex);
        tcp_send_hex_payload(hex);
    } else if (strcmp(what, "loc") == 0) {
        build_location_hex(hex, sizeof(hex));
        printk("Dynamic location hex: %s\r\n", hex);
        tcp_send_hex_payload(hex);
    } else if (strcmp(what, "raw") == 0) {
        if (rest == NULL || rest[0] == '\0') {
            printk("Usage: send raw <HEX>\r\n");
            return;
        }
        tcp_send_hex_payload(rest);
    } else {
        printk("Unknown send target: %s\r\n", what);
    }
}

static void handle_set_command(char *args)
{
    char *field = strtok(args, " ");

    if (field == NULL) {
        printk("Usage: set <field> <value>\r\n");
        return;
    }

    if (strcmp(field, "battery") == 0) {
        char *v = strtok(NULL, " ");
        if (!v) { printk("Usage: set battery low|medium|high\r\n"); return; }
        if (strcmp(v, "low") == 0) state.battery = 0x00;
        else if (strcmp(v, "medium") == 0) state.battery = 0x01;
        else if (strcmp(v, "high") == 0) state.battery = 0x10;
        else { printk("Invalid battery value\r\n"); return; }
        printk("battery set\r\n");
    } else if (strcmp(field, "charging") == 0) {
        char *v = strtok(NULL, " ");
        if (!v) { printk("Usage: set charging on|off\r\n"); return; }
        if (strcmp(v, "on") == 0) state.charging = 0x10;
        else if (strcmp(v, "off") == 0) state.charging = 0x01;
        else { printk("Invalid charging value\r\n"); return; }
        printk("charging set\r\n");
    } else if (strcmp(field, "opcode") == 0) {
        char *v = strtok(NULL, " ");
        if (!v) { printk("Usage: set opcode beacon|trusted|gps_lte|gps_safezone\r\n"); return; }
        if (strcmp(v, "beacon") == 0) state.opcode = OPCODE_BEACON;
        else if (strcmp(v, "trusted") == 0) state.opcode = OPCODE_TRUSTED;
        else if (strcmp(v, "gps_lte") == 0) state.opcode = OPCODE_GPS_LTE;
        else if (strcmp(v, "gps_safezone") == 0) state.opcode = OPCODE_GPS_SAFEZONE;
        else { printk("Invalid opcode\r\n"); return; }
        printk("opcode set to %s\r\n", opcode_name(state.opcode));
    } else if (strcmp(field, "pos") == 0) {
        char *lat = strtok(NULL, " ");
        char *lon = strtok(NULL, " ");
        char *acc = strtok(NULL, " ");
        char *spd = strtok(NULL, " ");
        int32_t lat_e6, lon_e6, acc_x10, spd_x10;
        if (!lat || !lon || !acc || !spd) {
            printk("Usage: set pos <lat> <lon> <accuracy_m> <speed_mps>\r\n"); return;
        }
        if (parse_scaled_i32(lat, 1000000, &lat_e6) ||
            parse_scaled_i32(lon, 1000000, &lon_e6) ||
            parse_scaled_i32(acc, 10, &acc_x10) ||
            parse_scaled_i32(spd, 10, &spd_x10) ||
            acc_x10 < 0 || spd_x10 < 0 || acc_x10 > 65535 || spd_x10 > 65535) {
            printk("Invalid pos values\r\n"); return;
        }
        state.lat_e6 = lat_e6;
        state.lon_e6 = lon_e6;
        state.accuracy_x10 = (uint16_t)acc_x10;
        state.speed_x10 = (uint16_t)spd_x10;
        printk("position set\r\n");
    } else if (strcmp(field, "imei") == 0) {
        char *v = strtok(NULL, " ");
        if (!v || strlen(v) < 15 || strlen(v) > 16) { printk("Usage: set imei <15_or_16_digits>\r\n"); return; }
        strncpy(state.imei, v, sizeof(state.imei) - 1);
        state.imei[sizeof(state.imei) - 1] = '\0';
        printk("imei set\r\n");
    } else if (strcmp(field, "lastupdate") == 0) {
        char *v = strtok(NULL, " ");
        uint16_t out;
        if (!v || parse_u16(v, &out)) { printk("Usage: set lastupdate <minutes>\r\n"); return; }
        state.last_update = out;
        printk("lastupdate set\r\n");
    } else if (strcmp(field, "versions") == 0) {
        char *sw = strtok(NULL, " ");
        char *fw = strtok(NULL, " ");
        uint8_t swv, fwv;
        if (!sw || !fw || parse_u8(sw, &swv) || parse_u8(fw, &fwv)) {
            printk("Usage: set versions <sw> <fw>\r\n"); return;
        }
        state.sw_version = swv;
        state.fw_version = fwv;
        printk("versions set\r\n");
    } else if (strcmp(field, "beacon") == 0) {
        char *v = strtok(NULL, " ");
        if (!v || parse_hex6(v, state.beacon_mac)) { printk("Usage: set beacon <12_hex_chars>\r\n"); return; }
        printk("beacon set\r\n");
    } else if (strcmp(field, "trusted") == 0) {
        char *v = strtok(NULL, " ");
        if (!v || parse_hex6(v, state.trusted_addr)) { printk("Usage: set trusted <12_hex_chars>\r\n"); return; }
        printk("trusted set\r\n");
    } else {
        printk("Unknown field: %s\r\n", field);
    }
}

static void handle_command(char *line)
{
    char *cmd = NULL;
    char *rest = NULL;

    split_first(line, &cmd, &rest);

    if (cmd == NULL || cmd[0] == '\0') {
        return;
    }

    if (strcmp(cmd, "help") == 0) {
        print_help();
    } else if (strcmp(cmd, "status") == 0) {
        print_status();
    } else if (strcmp(cmd, "connect") == 0) {
        char *ip = NULL;
        char *port_s = NULL;
        char *tail = NULL;
        uint16_t port = state.server_port;

        split_first(rest ? rest : "", &ip, &tail);
        split_first(tail ? tail : "", &port_s, &tail);

        if (!ip) {
            ip = state.server_ip;
        }
        if (port_s && parse_u16(port_s, &port)) {
            printk("Invalid port\r\n");
            return;
        }
        tcp_connect_to_server(ip, port);
    } else if (strcmp(cmd, "disconnect") == 0) {
        tcp_disconnect();
    } else if (strcmp(cmd, "recv") == 0) {
        tcp_recv_response();
    } else if (strcmp(cmd, "mode") == 0) {
        char *v = NULL;
        char *tail = NULL;
        split_first(rest ? rest : "", &v, &tail);
        if (!v) { printk("Usage: mode ascii_hex|binary\r\n"); return; }
        if (strcmp(v, "ascii_hex") == 0) state.mode = WIRE_ASCII_HEX;
        else if (strcmp(v, "binary") == 0) state.mode = WIRE_BINARY;
        else { printk("Invalid mode\r\n"); return; }
        printk("mode set to %s\r\n", mode_name());
    } else if (strcmp(cmd, "send") == 0) {
        handle_send_command(rest ? rest : "");
    } else if (strcmp(cmd, "preset") == 0) {
        char *p = NULL;
        char *tail = NULL;
        split_first(rest ? rest : "", &p, &tail);
        if (!p) { printk("Usage: preset normal|low|charging|outside|beacon|trusted\r\n"); return; }
        apply_preset(p);
    } else if (strcmp(cmd, "set") == 0) {
        handle_set_command(rest ? rest : "");
    } else {
        printk("Unknown command: %s. Type: help\r\n", cmd);
    }
}

static void cli_loop(void)
{
    char line[CLI_LINE_MAX];

    printk("\r\nSerial CLI ready. Type: help\r\n");
    printk("Recommended first command: connect %s %u\r\n", state.server_ip, state.server_port);

    while (true) {
        printk("micro> ");
        int n = read_line_serial(line, sizeof(line), true);
        if (n < 0) {
            printk("line read error: %d\r\n", n);
            continue;
        }
        handle_command(line);
    }
}

int main(void)
{
    LOG_INF("Micro serial simulator started");

    int err = serial_input_start();
    if (err) {
        return err;
    }

    while (!nrf_softsim_check_provisioned()) {
        int err = provision_softsim_from_serial();
        if (err) {
            LOG_ERR("Provisioning attempt failed. Paste the complete SoftSIM HEX profile again.");
            k_sleep(K_SECONDS(1));
        }
    }

    err = nrf_modem_lib_init();
    if (err) {
        LOG_ERR("Failed to initialize modem library: %d", err);
        return err;
    }

    err = modem_connect();
    if (err) {
        return err;
    }

    cli_loop();
    return 0;
}
